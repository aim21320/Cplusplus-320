//Areeya Techanitisawad
//Net_ID: 17at46
#include "fractionapp.h"
#include "ui_fractionapp.h"
#include <QMessageBox>
#include <iostream>
#include <QKeyEvent>
#include "fraction_cal.h"
#include <QString>


FractionApp::FractionApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::FractionApp)
{
    ui->setupUi(this);
}

FractionApp::~FractionApp()
{
    delete ui;
}
void FractionApp::add_checked() {
    if (ui->add1->isChecked()) {
        ui->minus->setChecked(false);
        ui->multiply->setChecked(false);
        ui->divide->setChecked(false);
    }
}

void FractionApp::minus_checked() {
    if (ui->minus->isChecked()) {
        ui->add1->setChecked(false);
        ui->multiply->setChecked(false);
        ui->divide->setChecked(false);
    }
}

void FractionApp::multiply_checked() {
    if (ui->multiply->isChecked()) {
        ui->minus->setChecked(false);
        ui->add1->setChecked(false);
        ui->divide->setChecked(false);
    }
}

void FractionApp::divide_checked() {
    if (ui->divide->isChecked()) {
        ui->minus->setChecked(false);
        ui->multiply->setChecked(false);
        ui->add1->setChecked(false);
    }
}

void FractionApp::on_eqButton_clicked()
{    int num1;
     int denom1;
     int num2;
     int denom2;
      if(ui->add1->isChecked() == false && ui->minus->isChecked() == false && ui->multiply->isChecked() == false && ui->divide->isChecked() == false){
          QMessageBox messageBox;
          messageBox.critical(0,"Error","An error has occured, Select an operation!");
          messageBox.setFixedSize(500,200);
          return;
      }
      if(ui->numerator1->text().isEmpty() || ui->numerator2->text().isEmpty()|| ui->denominator1->text().isEmpty()|| ui->denominator2->text().isEmpty()){
          QMessageBox messageBox;
          messageBox.critical(0,"Error","An error has occured, Text boxs are empty,Please put in numbers!");
          messageBox.setFixedSize(500,200);
          return;

      }

      if(ui->denominator1->text() == 0){
          QMessageBox messageBox;
          messageBox.about(0,"Error","An error has occured, Denominator on Fraction 1 cannot be 0!");
          messageBox.setFixedSize(500,200);
      }

       if(ui->denominator2->text() == 0){
       QMessageBox messageBox;
       messageBox.about(0,"Error","An error has occured, Denominator on Fraction 2 cannot be 0!");
       messageBox.setFixedSize(500,200);
   }



      try {
          QString num1String = ui->numerator1->text();
          num1 = num1String.toInt();

       }  catch (...) {
          QMessageBox messageBox;
          messageBox.critical(0,"Error","An error has occured, Please enter numbers in to the numerator of the first fraction!");
          messageBox.setFixedSize(500,200);
          return;
       }

       try {
           QString num2String = ui->numerator2->text();
           num2 = num2String.toInt();

        }  catch (...) {
           QMessageBox messageBox;
           messageBox.critical(0,"Error","An error has occured, Please enter numbers in to the numerator of the second fraction!");
           messageBox.setFixedSize(500,200);
           return;
        }

       try {
           QString denom1String = ui->denominator1->text();
           denom1 = denom1String.toInt();

        }  catch (...) {
           QMessageBox messageBox;
           messageBox.critical(0,"Error","An error has occured, Please enter numbers in to the denominator of the first fraction!");
           messageBox.setFixedSize(500,200);
           return;
        }

       try {
           QString denom2String = ui->denominator2->text();
           denom2 = denom2String.toInt();

        }  catch (...) {
           QMessageBox messageBox;
           messageBox.critical(0,"Error","An error has occured, Please enter numbers in to the denominator of the second fraction!");
           messageBox.setFixedSize(500,200);
           return;
        }




        int* answer;
          if(ui->add1->isChecked()){
              answer = addFraction(num1, denom1, num2, denom2);
               std::cout << answer[0] << "/" << answer[1] << std::endl;
          }
          else if (ui->minus->isChecked()) {
              answer = minusFraction(num1, denom1, num2, denom2);
          } else if (ui->multiply->isChecked()) {
              answer = multuplyFraction(num1, denom1, num2, denom2);
          } else if (ui->divide->isChecked()) {
              answer = divideFraction(num1, denom1, num2, denom2);
          }

          ui->numerator3->setText(QString::number(answer[0]));
          ui->denominator3->setText(QString::number(answer[1]));


}




 void FractionApp::num1_text()
 {
     ui->numerator3->textChanged("");
     ui->denominator3->textChanged("");
 }

 void FractionApp::num2_text()
 {
     ui->numerator3->textChanged("");
     ui->denominator3->textChanged("");
 }
 void FractionApp::deno1_text()
 {
     ui->numerator3->textChanged("");
     ui->denominator3->textChanged("");
 }
 void FractionApp::deno2_text()
 {
     ui->numerator3->textChanged("");
     ui->denominator3->textChanged("");
 }



QSet<int> pressedKeys;
void FractionApp::keyPressEvent(QKeyEvent *event)

{   if(event->type()==QEvent::KeyPress){
        pressedKeys += ((QKeyEvent*)event)->key();
    if(pressedKeys.contains(Qt::Key_Alt) && pressedKeys.contains(Qt::Key_C)){
        this->close();
    }

    if(pressedKeys.contains(Qt::Key_Alt) && pressedKeys.contains(Qt::Key_Q)){
            ui->add1->setChecked(true);
    }
    if(pressedKeys.contains(Qt::Key_Alt) && pressedKeys.contains(Qt::Key_W)){
            ui->minus->setChecked(true);
    }
    if(pressedKeys.contains(Qt::Key_Alt) && pressedKeys.contains(Qt::Key_E)){
            ui->multiply->setChecked(true);
    }
    if(pressedKeys.contains(Qt::Key_Alt) && pressedKeys.contains(Qt::Key_R)){
            ui->divide->setChecked(true);
    }
    if(event->key() == Qt::Key_Escape){
        this->close();
    }

    if(pressedKeys.contains(Qt::Key_Enter)){
        ui->eqButton->setChecked(true);
    }

    }

}
