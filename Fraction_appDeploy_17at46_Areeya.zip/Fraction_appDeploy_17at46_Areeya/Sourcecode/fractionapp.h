//Areeya Techanitisawad
//Net_ID: 17at46
#ifndef FRACTIONAPP_H
#define FRACTIONAPP_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class FractionApp; }
QT_END_NAMESPACE

class FractionApp : public QMainWindow
{
    Q_OBJECT

public:
    FractionApp(QWidget *parent = nullptr);
    ~FractionApp();


private slots:
    void on_eqButton_clicked();
    void add_checked();
    void minus_checked();
    void multiply_checked();
    void divide_checked();
    void keyPressEvent(QKeyEvent *);
    void num1_text();
    void num2_text();
    void deno1_text();
    void deno2_text();

private:
    Ui::FractionApp *ui;
};
#endif // FRACTIONAPP_H
