#include "fractionapp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FractionApp w;
    w.show();
    return a.exec();
}
